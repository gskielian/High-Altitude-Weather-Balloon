Raspberry Pi Setup
==================



#Get The Tools
```bash
sudo apt-get update
sudo apt-get install usb-modeswitch
sudo apt-get install vim
```

#Change some files

