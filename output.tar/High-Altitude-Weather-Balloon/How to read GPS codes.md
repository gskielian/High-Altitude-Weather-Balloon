How to read GPS codes
=====================

https://learn.sparkfun.com/tutorials/gps-basics/message-formats
