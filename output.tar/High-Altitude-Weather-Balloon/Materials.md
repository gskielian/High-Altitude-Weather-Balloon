Materials
=========


1. Raspberry Pi Rev B
2. Ethernet Connection To Internet (or wireless internet dongle -- google search wireless setup Raspberry Pi for more info on that)
3. Virgin Mobile U600 3G USB Dongle
4. Arduino Uno Rev3
5. Adafruit GPS Module
7. High Altitude Weather Balloon
8. Helium Dewar
9. Styrofoam Container
10. Jumper Cables
11. Hand Warmers
12. 9v Batteries
13. Voltage Regulator
