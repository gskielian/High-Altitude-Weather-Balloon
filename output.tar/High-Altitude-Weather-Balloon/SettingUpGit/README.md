Setting Up Git
==============



```bash
sudo apt-get intall git-core
```
