3G Module Setup
===============


[The 3G Dongle we Tested] (http://www.virginmobileusa.com/shop/mobile-broadband/broadband-2-go/franklin-wireless-u600/features/#plan)

#Activate Plan
Click on Activate on the top right hand corner of the screen, and select "Broadband 2 Go" to activate the module.

